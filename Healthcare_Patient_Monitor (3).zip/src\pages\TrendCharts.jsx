import { useHealth } from '../context/HealthContext';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, BarChart, Bar
} from 'recharts';

const TrendCharts = () => {
  const { vitals } = useHealth();
  
  const data = vitals.map(v => ({
    name: new Date(v.date).toLocaleDateString([], { month: 'short', day: 'numeric' }),
    bpSystolic: parseInt(v.bp.split('/')[0]),
    bpDiastolic: parseInt(v.bp.split('/')[1]),
    sugar: v.sugar,
    hr: v.hr,
    o2: v.o2
  }));

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Health Trends</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card h-[400px]">
          <h3 className="text-lg font-bold mb-4">Blood Pressure Trends (mmHg)</h3>
          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis domain={[60, 200]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="bpSystolic" stroke="#ef4444" name="Systolic" strokeWidth={2} />
              <Line type="monotone" dataKey="bpDiastolic" stroke="#3b82f6" name="Diastolic" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card h-[400px]">
          <h3 className="text-lg font-bold mb-4">Blood Sugar Levels (mg/dL)</h3>
          <ResponsiveContainer width="100%" height="90%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="sugarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis domain={[40, 300]} />
              <Tooltip />
              <Area type="monotone" dataKey="sugar" stroke="#f59e0b" fillOpacity={1} fill="url(#sugarGradient)" name="Sugar Level" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card h-[400px]">
          <h3 className="text-lg font-bold mb-4">Heart Rate (bpm)</h3>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis domain={[40, 160]} />
              <Tooltip />
              <Bar dataKey="hr" fill="#ec4899" radius={[4, 4, 0, 0]} name="Heart Rate" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card h-[400px]">
          <h3 className="text-lg font-bold mb-4">Oxygen Saturation (%)</h3>
          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis domain={[80, 100]} />
              <Tooltip />
              <Line type="stepAfter" dataKey="o2" stroke="#10b981" strokeWidth={3} name="Oxygen Saturation" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default TrendCharts;

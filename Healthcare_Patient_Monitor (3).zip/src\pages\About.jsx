import { Heart, ShieldCheck, Zap, Users, Globe, Mail } from 'lucide-react';

const About = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-12 py-8">
      <section className="text-center space-y-4">
        <div className="inline-flex items-center justify-center p-3 bg-hospital-100 rounded-2xl mb-2 text-hospital-600">
          <Heart size={40} fill="currentColor" />
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">About HealthPlus</h1>
        <p className="text-xl text-slate-500 max-w-2xl mx-auto">
          A cutting-edge patient monitoring system designed for chronic condition management and real-time vital tracking.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-3">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
            <Zap size={24} />
          </div>
          <h3 className="text-xl font-bold">Real-time Insights</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            Instant updates on health metrics with interactive charts and trend analysis using Recharts technology.
          </p>
        </div>
        <div className="space-y-3">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center">
            <ShieldCheck size={24} />
          </div>
          <h3 className="text-xl font-bold">Local First</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            Your data never leaves your device. We use browser LocalStorage for maximum privacy and offline availability.
          </p>
        </div>
        <div className="space-y-3">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center">
            <Users size={24} />
          </div>
          <h3 className="text-xl font-bold">Professional Care</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            Designed in collaboration with healthcare professionals to ensure clinical relevance and user-friendly experience.
          </p>
        </div>
      </div>

      <section className="card bg-slate-900 text-white p-8 md:p-12 overflow-hidden relative">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-md">
            <h2 className="text-3xl font-bold mb-4">Empowering Patients, Saving Lives.</h2>
            <p className="text-slate-300 mb-6">Join thousands of users who trust HealthPlus for their daily health monitoring needs.</p>
            <div className="flex gap-4">
              <button className="btn-primary border-none font-bold px-6">Get Started</button>
              <button className="text-white font-bold flex items-center gap-2 hover:underline"><Globe size={18} /> Visit Website</button>
            </div>
          </div>
          <div className="hidden lg:block lg:w-64 lg:h-64 opacity-20">
             <Heart size={200} />
          </div>
        </div>
      </section>

      <section className="text-center space-y-6">
        <h2 className="text-2xl font-bold">Our Contact Information</h2>
        <div className="flex flex-col md:flex-row justify-center items-center gap-8 text-slate-600 font-medium">
          <div className="flex items-center gap-2">
            <Mail size={18} className="text-hospital-600" />
            <span>support@healthplus.example</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe size={18} className="text-hospital-600" />
            <span>www.healthplus-system.example</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;

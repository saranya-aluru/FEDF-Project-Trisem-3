import { useHealth } from '../context/HealthContext';
import { Bell, CheckCircle, Trash2, Clock, Info, AlertTriangle } from 'lucide-react';

const Notifications = () => {
  const { notifications, setNotifications } = useHealth();

  const markAsRead = (id) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const deleteNotif = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const clearAll = () => {
    if (confirm('Clear all notifications?')) setNotifications([]);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notification Center</h1>
        <button onClick={clearAll} className="text-sm font-semibold text-red-600 hover:underline">Clear All</button>
      </div>

      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="card text-center py-20">
            <Bell className="mx-auto text-slate-200 mb-4" size={64} />
            <h3 className="text-lg font-bold text-slate-900">All caught up!</h3>
            <p className="text-slate-500">No new notifications to show.</p>
          </div>
        ) : (
          notifications.map(notif => (
            <div key={notif.id} className={`card p-4 flex gap-4 transition-all ${notif.read ? 'opacity-80 grayscale-[0.5]' : 'border-l-4 border-l-hospital-600'}`}>
              <div className={`p-2 rounded-xl h-fit ${
                notif.severity === 'critical' ? 'bg-red-100 text-red-600' : 
                notif.severity === 'warning' ? 'bg-amber-100 text-amber-600' : 'bg-hospital-100 text-hospital-600'
              }`}>
                {notif.severity === 'critical' ? <AlertTriangle size={20} /> : <Info size={20} />}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h4 className={`font-bold ${notif.read ? 'text-slate-600' : 'text-slate-900'}`}>{notif.title}</h4>
                  <div className="flex items-center gap-1 text-[10px] text-slate-400 font-medium">
                    <Clock size={10} /> {new Date(notif.time).toLocaleString()}
                  </div>
                </div>
                <p className="text-sm text-slate-600 mb-3">{notif.message}</p>
                <div className="flex gap-3">
                  {!notif.read && (
                    <button onClick={() => markAsRead(notif.id)} className="text-xs font-bold text-hospital-600 flex items-center gap-1">
                      <CheckCircle size={14} /> Mark as read
                    </button>
                  )}
                  <button onClick={() => deleteNotif(notif.id)} className="text-xs font-bold text-slate-400 hover:text-red-600 flex items-center gap-1">
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Notifications;

import { Bell, Search, User, Menu } from 'lucide-react';
import { useHealth } from '../context/HealthContext';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const { profile, notifications } = useHealth();
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 md:px-8 flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center gap-4">
        <button className="lg:hidden p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">
          <Menu size={24} />
        </button>
        <div className="hidden md:flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-4 py-2 rounded-full w-64 lg:w-96">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder="Search records, medications..." 
            className="bg-transparent border-none outline-none text-sm w-full"
          />
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-6">
        <Link to="/notifications" className="relative p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <Bell size={22} />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900">
              {unreadCount}
            </span>
          )}
        </Link>

        <div className="h-8 w-px bg-slate-200 dark:bg-slate-700 hidden md:block"></div>

        <Link to="/profile" className="flex items-center gap-3 pl-2 group">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-semibold text-slate-900 dark:text-white leading-tight">{profile.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Patient ID: #HP-4402</p>
          </div>
          <div className="w-10 h-10 rounded-full border-2 border-hospital-100 dark:border-hospital-900 overflow-hidden group-hover:border-hospital-500 transition-colors">
            <img src={profile.photo} alt="Avatar" className="w-full h-full object-cover" />
          </div>
        </Link>
      </div>
    </header>
  );
};

export default Navbar;

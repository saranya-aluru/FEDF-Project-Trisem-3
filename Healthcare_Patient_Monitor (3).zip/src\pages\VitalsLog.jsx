import { useState } from 'react';
import { useHealth } from '../context/HealthContext';
import { Activity, Plus, Trash2, Edit3, CheckCircle, AlertCircle } from 'lucide-react';

const VitalsLog = () => {
  const { vitals, setVitals } = useHealth();
  const [isAdding, setIsAdding] = useState(false);
  const [newVital, setNewVital] = useState({
    bp: '120/80',
    sugar: 100,
    hr: 72,
    o2: 98,
    temp: 98.6,
    weight: 70,
    date: new Date().toISOString().split('T')[0] + 'T' + new Date().toTimeString().split(' ')[0].slice(0, 5)
  });

  const handleAdd = (e) => {
    e.preventDefault();
    setVitals(prev => [...prev, { ...newVital, id: Date.now() }]);
    setIsAdding(false);
    // Reset form
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      setVitals(vitals.filter(v => v.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Vitals Logging</h1>
        {!isAdding && (
          <button onClick={() => setIsAdding(true)} className="btn-primary">
            <Plus size={18} /> Add New Entry
          </button>
        )}
      </div>

      {isAdding && (
        <div className="card animate-in fade-in slide-in-from-top-4 duration-300">
          <h2 className="text-lg font-bold mb-4">New Vital Entry</h2>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold">Blood Pressure (mmHg)</label>
              <input 
                type="text" 
                placeholder="120/80"
                value={newVital.bp}
                onChange={e => setNewVital({...newVital, bp: e.target.value})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Blood Sugar (mg/dL)</label>
              <input 
                type="number" 
                value={newVital.sugar}
                onChange={e => setNewVital({...newVital, sugar: parseInt(e.target.value)})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Heart Rate (bpm)</label>
              <input 
                type="number" 
                value={newVital.hr}
                onChange={e => setNewVital({...newVital, hr: parseInt(e.target.value)})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Oxygen Saturation (%)</label>
              <input 
                type="number" 
                value={newVital.o2}
                onChange={e => setNewVital({...newVital, o2: parseInt(e.target.value)})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Temperature (°F)</label>
              <input 
                type="number" 
                step="0.1" 
                value={newVital.temp}
                onChange={e => setNewVital({...newVital, temp: parseFloat(e.target.value)})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Weight (kg)</label>
              <input 
                type="number" 
                step="0.1"
                value={newVital.weight}
                onChange={e => setNewVital({...newVital, weight: parseFloat(e.target.value)})}
                className="input-field" 
                required 
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-semibold">Date & Time</label>
              <input 
                type="datetime-local" 
                value={newVital.date}
                onChange={e => setNewVital({...newVital, date: e.target.value})}
                className="input-field" 
                required 
              />
            </div>
            <div className="md:col-span-3 lg:col-span-4 flex justify-end gap-3 pt-4">
              <button type="button" onClick={() => setIsAdding(false)} className="btn-secondary">Cancel</button>
              <button type="submit" className="btn-primary">Save Entry</button>
            </div>
          </form>
        </div>
      )}

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">
                <th className="px-4 py-4 font-semibold">Date & Time</th>
                <th className="px-4 py-4 font-semibold">BP (mmHg)</th>
                <th className="px-4 py-4 font-semibold">Sugar (mg/dL)</th>
                <th className="px-4 py-4 font-semibold">Heart Rate</th>
                <th className="px-4 py-4 font-semibold">O2 %</th>
                <th className="px-4 py-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {vitals.slice().reverse().map(item => {
                const isHighBP = parseInt(item.bp.split('/')[0]) > 140;
                const isHighSugar = item.sugar > 180;
                
                return (
                  <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="px-4 py-4 text-sm font-medium">{new Date(item.date).toLocaleString()}</td>
                    <td className="px-4 py-4">
                      <span className={`flex items-center gap-1 ${isHighBP ? 'text-red-600 font-bold' : ''}`}>
                        {item.bp} {isHighBP && <AlertCircle size={14} />}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`flex items-center gap-1 ${isHighSugar ? 'text-red-600 font-bold' : ''}`}>
                        {item.sugar} {isHighSugar && <AlertCircle size={14} />}
                      </span>
                    </td>
                    <td className="px-4 py-4">{item.hr} bpm</td>
                    <td className="px-4 py-4">{item.o2}%</td>
                    <td className="px-4 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button className="p-1.5 text-slate-400 hover:text-hospital-600"><Edit3 size={16} /></button>
                        <button onClick={() => handleDelete(item.id)} className="p-1.5 text-slate-400 hover:text-red-600"><Trash2 size={16} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default VitalsLog;

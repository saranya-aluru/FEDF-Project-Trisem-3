import { useState } from 'react';
import { useHealth } from '../context/HealthContext';
import { Pill, Plus, CheckCircle2, Circle, Clock, Trash2, Edit2 } from 'lucide-react';

const MedicationTracker = () => {
  const { medications, setMedications } = useHealth();
  const [isAdding, setIsAdding] = useState(false);
  const [newMed, setNewMed] = useState({
    name: '',
    dosage: '',
    frequency: 'Once daily',
    time: '09:00',
    status: 'Pending'
  });

  const handleAdd = (e) => {
    e.preventDefault();
    setMedications([...medications, { ...newMed, id: Date.now() }]);
    setIsAdding(false);
    setNewMed({ name: '', dosage: '', frequency: 'Once daily', time: '09:00', status: 'Pending' });
  };

  const toggleStatus = (id) => {
    setMedications(medications.map(m => 
      m.id === id ? { ...m, status: m.status === 'Taken' ? 'Pending' : 'Taken' } : m
    ));
  };

  const deleteMed = (id) => {
    if (confirm('Remove this medication?')) {
      setMedications(medications.filter(m => m.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Medication Tracker</h1>
        <button onClick={() => setIsAdding(true)} className="btn-primary">
          <Plus size={18} /> Add Medication
        </button>
      </div>

      {isAdding && (
        <div className="card">
          <h3 className="font-bold mb-4">Add New Medication</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <input 
              type="text" 
              placeholder="Medicine Name (e.g. Metformin)" 
              className="input-field"
              value={newMed.name}
              onChange={e => setNewMed({...newMed, name: e.target.value})}
              required
            />
            <input 
              type="text" 
              placeholder="Dosage (e.g. 500mg)" 
              className="input-field"
              value={newMed.dosage}
              onChange={e => setNewMed({...newMed, dosage: e.target.value})}
              required
            />
            <select 
              className="input-field"
              value={newMed.frequency}
              onChange={e => setNewMed({...newMed, frequency: e.target.value})}
            >
              <option>Once daily</option>
              <option>Twice daily</option>
              <option>Thrice daily</option>
              <option>Every 8 hours</option>
            </select>
            <input 
              type="time" 
              className="input-field"
              value={newMed.time}
              onChange={e => setNewMed({...newMed, time: e.target.value})}
            />
            <div className="md:col-span-2 lg:col-span-4 flex justify-end gap-2">
              <button type="button" onClick={() => setIsAdding(false)} className="btn-secondary">Cancel</button>
              <button type="submit" className="btn-primary">Save Medication</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {medications.map(med => (
          <div key={med.id} className={`card flex flex-col justify-between ${med.status === 'Taken' ? 'bg-slate-50 opacity-75' : ''}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex gap-4">
                <div className={`p-3 rounded-xl ${med.status === 'Taken' ? 'bg-green-100 text-green-600' : 'bg-hospital-100 text-hospital-600'}`}>
                  <Pill size={24} />
                </div>
                <div>
                  <h3 className={`font-bold text-lg ${med.status === 'Taken' ? 'line-through text-slate-500' : ''}`}>{med.name}</h3>
                  <p className="text-slate-500 text-sm font-medium">{med.dosage} • {med.frequency}</p>
                </div>
              </div>
              <button 
                onClick={() => toggleStatus(med.id)}
                className={`p-2 rounded-full transition-colors ${
                  med.status === 'Taken' ? 'text-green-600' : 'text-slate-300 hover:text-green-500'
                }`}
              >
                {med.status === 'Taken' ? <CheckCircle2 size={24} fill="currentColor" className="text-white fill-green-500" /> : <Circle size={24} />}
              </button>
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-4 mt-2">
              <div className="flex items-center gap-2 text-slate-500 text-sm">
                <Clock size={14} />
                <span>Scheduled: {med.time}</span>
              </div>
              <div className="flex gap-1">
                <button className="p-1.5 text-slate-400 hover:text-hospital-600"><Edit2 size={16} /></button>
                <button onClick={() => deleteMed(med.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 size={16} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {medications.length === 0 && (
        <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
          <Pill className="mx-auto text-slate-300 mb-4" size={48} />
          <p className="text-slate-500 font-medium">No medications added yet.</p>
        </div>
      )}
    </div>
  );
};

export default MedicationTracker;

import { useState } from 'react';
import { useHealth } from '../context/HealthContext';
import { User, Phone, Mail, MapPin, Save, Edit2, ShieldAlert } from 'lucide-react';
import CopyButton from '../components/CopyButton';

const Profile = () => {
  const { profile, setProfile } = useHealth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(profile);

  const handleSave = (e) => {
    e.preventDefault();
    setProfile(formData);
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Patient Profile</h1>
        <button 
          onClick={() => setIsEditing(!isEditing)}
          className="btn-secondary"
        >
          {isEditing ? 'Cancel' : <><Edit2 size={18} /> Edit Profile</>}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 card text-center">
          <div className="relative inline-block mx-auto mb-4">
            <img 
              src={profile.photo} 
              alt={profile.name} 
              className="w-32 h-32 rounded-full object-cover border-4 border-hospital-100 shadow-lg"
            />
            {isEditing && (
              <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                <span className="text-white text-xs font-bold">Change Photo</span>
              </div>
            )}
          </div>
          <h2 className="text-xl font-bold">{profile.name}</h2>
          <p className="text-slate-500 mb-4">{profile.age} Years • {profile.gender}</p>
          <div className="inline-flex items-center gap-1 bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold border border-red-100">
            <ShieldAlert size={14} /> Type 2 Diabetic
          </div>
        </div>

        <div className="lg:col-span-2 card">
          <form onSubmit={handleSave} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Full Name</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="input-field disabled:bg-slate-50 disabled:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Blood Group</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  value={formData.bloodGroup}
                  onChange={e => setFormData({...formData, bloodGroup: e.target.value})}
                  className="input-field"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Age</label>
                <input 
                  type="number" 
                  disabled={!isEditing}
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: e.target.value})}
                  className="input-field"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Gender</label>
                <select 
                  disabled={!isEditing}
                  value={formData.gender}
                  onChange={e => setFormData({...formData, gender: e.target.value})}
                  className="input-field"
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Medical Conditions</label>
              <textarea 
                rows="3"
                disabled={!isEditing}
                value={formData.medicalConditions}
                onChange={e => setFormData({...formData, medicalConditions: e.target.value})}
                className="input-field resize-none"
              ></textarea>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Emergency Contact</label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  disabled={!isEditing}
                  value={formData.emergencyContact}
                  onChange={e => setFormData({...formData, emergencyContact: e.target.value})}
                  className="input-field flex-1"
                />
                <CopyButton text={formData.emergencyContact} />
              </div>
            </div>

            {isEditing && (
              <div className="flex justify-end">
                <button type="submit" className="btn-primary">
                  <Save size={18} /> Save Changes
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;

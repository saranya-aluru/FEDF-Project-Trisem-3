import { useState, useRef } from 'react';
import { useHealth } from '../context/HealthContext';
import { FileDown, Download, CheckCircle, FileText, Activity, Pill } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ExportPDF = () => {
  const { profile, vitals, medications, notes } = useHealth();
  const [isExporting, setIsExporting] = useState(false);
  const reportRef = useRef();

  const handleExport = async () => {
    setIsExporting(true);
    const element = reportRef.current;
    const canvas = await html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`Patient_Report_${profile.name.replace(' ', '_')}.pdf`);
    setIsExporting(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Export Medical Reports</h1>
        <button 
          onClick={handleExport} 
          disabled={isExporting}
          className="btn-primary"
        >
          {isExporting ? 'Generating PDF...' : <><Download size={18} /> Download Full Report</>}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 bg-gradient-to-br from-hospital-600 to-hospital-800 text-white border-none">
          <FileText size={32} className="mb-4 opacity-70" />
          <h3 className="text-lg font-bold mb-1">Comprehensive Report</h3>
          <p className="text-sm opacity-80 mb-4">Includes profile, all vitals, medications, and notes.</p>
          <button className="bg-white text-hospital-700 w-full py-2 rounded-lg text-sm font-bold shadow-lg">Preview</button>
        </div>
        <div className="card p-6 border-hospital-100 bg-hospital-50">
          <Activity size={32} className="mb-4 text-hospital-600" />
          <h3 className="text-lg font-bold mb-1 text-hospital-900">Vitals Log Only</h3>
          <p className="text-sm text-slate-500 mb-4">Download a tabular view of all vital records.</p>
          <button className="btn-secondary w-full border-hospital-200 text-hospital-700">Export CSV</button>
        </div>
        <div className="card p-6">
          <Pill size={32} className="mb-4 text-slate-400" />
          <h3 className="text-lg font-bold mb-1">Medication List</h3>
          <p className="text-sm text-slate-500 mb-4">Printable schedule for current medications.</p>
          <button className="btn-secondary w-full">Print Schedule</button>
        </div>
      </div>

      <div className="card">
        <h2 className="text-lg font-bold mb-4">Report Preview</h2>
        <div 
          ref={reportRef} 
          className="bg-white p-8 border border-slate-200 rounded-lg shadow-inner max-w-[800px] mx-auto text-slate-900"
        >
          {/* PDF Content Template */}
          <div className="flex justify-between border-b-2 border-hospital-600 pb-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold text-hospital-700 tracking-tight">HealthPlus</h1>
              <p className="text-sm text-slate-500 uppercase font-semibold">Patient Monitoring System</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold">Report ID: #RP-2026-001</p>
              <p className="text-sm text-slate-500">Generated: {new Date().toLocaleDateString()}</p>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4 border-l-4 border-hospital-500 pl-3">Patient Information</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <p><span className="font-bold">Name:</span> {profile.name}</p>
              <p><span className="font-bold">Age/Gender:</span> {profile.age} / {profile.gender}</p>
              <p><span className="font-bold">Blood Group:</span> {profile.bloodGroup}</p>
              <p><span className="font-bold">Primary Condition:</span> {profile.medicalConditions}</p>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4 border-l-4 border-hospital-500 pl-3">Current Medications</h2>
            <table className="w-full text-xs text-left border-collapse border border-slate-200">
              <thead>
                <tr className="bg-slate-50">
                  <th className="border border-slate-200 p-2">Medicine</th>
                  <th className="border border-slate-200 p-2">Dosage</th>
                  <th className="border border-slate-200 p-2">Frequency</th>
                </tr>
              </thead>
              <tbody>
                {medications.map(m => (
                  <tr key={m.id}>
                    <td className="border border-slate-200 p-2 font-medium">{m.name}</td>
                    <td className="border border-slate-200 p-2">{m.dosage}</td>
                    <td className="border border-slate-200 p-2">{m.frequency}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div>
            <h2 className="text-xl font-bold mb-4 border-l-4 border-hospital-500 pl-3">Recent Vitals Summary</h2>
            <table className="w-full text-xs text-left border-collapse border border-slate-200">
              <thead>
                <tr className="bg-slate-50">
                  <th className="border border-slate-200 p-2">Date</th>
                  <th className="border border-slate-200 p-2">BP</th>
                  <th className="border border-slate-200 p-2">Sugar</th>
                  <th className="border border-slate-200 p-2">HR</th>
                </tr>
              </thead>
              <tbody>
                {vitals.slice(-5).reverse().map(v => (
                  <tr key={v.id}>
                    <td className="border border-slate-200 p-2">{new Date(v.date).toLocaleDateString()}</td>
                    <td className="border border-slate-200 p-2">{v.bp}</td>
                    <td className="border border-slate-200 p-2">{v.sugar}</td>
                    <td className="border border-slate-200 p-2">{v.hr}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-12 pt-6 border-t border-slate-100 text-[10px] text-center text-slate-400">
            This is a computer-generated report from HealthPlus Patient Monitoring System. 
            Final diagnosis should be confirmed by a licensed medical professional.
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExportPDF;

import { useState } from 'react';
import { useHealth } from '../context/HealthContext';
import { ClipboardList, Plus, Search, Trash2, Edit2, Calendar, User as UserIcon } from 'lucide-react';

const DoctorNotes = () => {
  const { notes, setNotes } = useHealth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newNote, setNewNote] = useState({ content: '', author: 'Dr. Smith' });

  const handleAdd = (e) => {
    e.preventDefault();
    setNotes([{ ...newNote, id: Date.now(), date: new Date().toISOString().split('T')[0] }, ...notes]);
    setIsAdding(false);
    setNewNote({ content: '', author: 'Dr. Smith' });
  };

  const filteredNotes = notes.filter(n => 
    n.content.toLowerCase().includes(searchTerm.toLowerCase()) || 
    n.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold">Doctor Notes</h1>
        <button onClick={() => setIsAdding(true)} className="btn-primary">
          <Plus size={18} /> New Note
        </button>
      </div>

      <div className="flex items-center gap-2 bg-white dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800">
        <Search size={18} className="text-slate-400" />
        <input 
          type="text" 
          placeholder="Search by keywords or doctor name..." 
          className="bg-transparent border-none outline-none text-sm w-full py-1"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {isAdding && (
        <div className="card">
          <h3 className="font-bold mb-4">Add Medical Note</h3>
          <form onSubmit={handleAdd} className="space-y-4">
            <textarea 
              className="input-field min-h-[120px]" 
              placeholder="Enter consultation details, observations, or advice..." 
              value={newNote.content}
              onChange={e => setNewNote({...newNote, content: e.target.value})}
              required
            ></textarea>
            <div className="flex flex-col md:flex-row gap-4">
              <input 
                type="text" 
                placeholder="Doctor Name" 
                className="input-field" 
                value={newNote.author}
                onChange={e => setNewNote({...newNote, author: e.target.value})}
                required
              />
              <div className="flex-1 flex justify-end gap-2">
                <button type="button" onClick={() => setIsAdding(false)} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Add Note</button>
              </div>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-4">
        {filteredNotes.map(note => (
          <div key={note.id} className="card group">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-hospital-100 text-hospital-600 p-2 rounded-lg">
                  <ClipboardList size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{note.author}</h4>
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {new Date(note.date).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-1.5 text-slate-400 hover:text-hospital-600"><Edit2 size={16} /></button>
                <button 
                  onClick={() => setNotes(notes.filter(n => n.id !== note.id))}
                  className="p-1.5 text-slate-400 hover:text-red-500"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            <p className="text-slate-700 leading-relaxed text-sm bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              {note.content}
            </p>
          </div>
        ))}
        {filteredNotes.length === 0 && (
          <div className="text-center py-20">
            <ClipboardList className="mx-auto text-slate-300 mb-4" size={48} />
            <p className="text-slate-500">No notes found for "{searchTerm}"</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorNotes;

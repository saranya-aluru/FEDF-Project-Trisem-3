import { useHealth } from '../context/HealthContext';
import { Activity, Bell, Heart, Thermometer, Droplets, Weight } from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';
import CopyButton from '../components/CopyButton';

const StatCard = ({ title, value, unit, icon: Icon, color, trend }) => (
  <div className="card flex items-start justify-between">
    <div>
      <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
      <div className="flex items-baseline gap-1">
        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{value}</h3>
        <span className="text-sm text-slate-500">{unit}</span>
      </div>
      {trend && (
        <p className={`text-xs mt-2 font-medium ${trend > 0 ? 'text-red-500' : 'text-green-500'}`}>
          {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}% from yesterday
        </p>
      )}
    </div>
    <div className={`p-3 rounded-xl bg-${color}-50 dark:bg-${color}-900/20 text-${color}-600 dark:text-${color}-400`}>
      <Icon size={24} />
    </div>
  </div>
);

const Dashboard = () => {
  const { vitals, notifications, profile } = useHealth();
  const latestVitals = vitals[vitals.length - 1] || {};
  
  const chartData = vitals.slice(-7).map(v => ({
    time: new Date(v.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    bp: parseInt(v.bp.split('/')[0]),
    sugar: v.sugar,
    hr: v.hr
  }));

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Welcome back, {profile.name}!</h1>
          <p className="text-slate-500">Your health overview for today.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-green-100 text-green-800 border border-green-200">
            Records Synchronized
          </span>
          <CopyButton text={`Latest Vitals: BP ${latestVitals.bp}, Sugar ${latestVitals.sugar}`} />
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Blood Pressure" value={latestVitals.bp} unit="mmHg" icon={Activity} color="rose" />
        <StatCard title="Heart Rate" value={latestVitals.hr} unit="bpm" icon={Heart} color="red" />
        <StatCard title="Blood Sugar" value={latestVitals.sugar} unit="mg/dL" icon={Droplets} color="amber" />
        <StatCard title="Body Temp" value={latestVitals.temp} unit="°F" icon={Thermometer} color="blue" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card h-[400px] flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold">Vital Trends (Last 7 Logs)</h2>
            <select className="bg-slate-50 dark:bg-slate-800 border-none text-xs font-medium rounded-lg px-2 py-1 outline-none">
              <option>Weekly</option>
              <option>Monthly</option>
            </select>
          </div>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorBp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="bp" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorBp)" />
                <Area type="monotone" dataKey="sugar" stroke="#f59e0b" fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card overflow-hidden flex flex-col">
          <h2 className="text-lg font-bold mb-4">Recent Alerts</h2>
          <div className="space-y-4 overflow-y-auto pr-2 flex-1">
            {notifications.length === 0 ? (
              <p className="text-center text-slate-500 py-8 italic">No active alerts</p>
            ) : (
              notifications.slice(0, 5).map(node => (
                <div key={node.id} className={`p-4 rounded-xl border-l-4 ${
                  node.severity === 'critical' ? 'bg-red-50 border-red-500 text-red-700' : 'bg-amber-50 border-amber-500 text-amber-700'
                }`}>
                  <p className="text-xs font-bold uppercase mb-1">{node.title}</p>
                  <p className="text-sm">{node.message}</p>
                </div>
              ))
            )}
          </div>
          <button className="mt-4 text-sm font-semibold text-hospital-600 hover:text-hospital-700">View All Notifications</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

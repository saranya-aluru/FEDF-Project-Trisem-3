import { useState, useEffect, createContext, useContext } from 'react';

const HealthContext = createContext();

export const useHealth = () => useContext(HealthContext);

const DEFAULT_PROFILE = {
  name: 'John Doe',
  age: 45,
  gender: 'Male',
  bloodGroup: 'O+',
  medicalConditions: 'Hypertension, Type 2 Diabetes',
  emergencyContact: 'Jane Doe (+1 234 567 890)',
  photo: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=200&h=200',
};

const DUMMY_VITALS = [
  { id: 1, date: '2026-06-01T08:00', bp: '130/85', sugar: 110, hr: 72, o2: 98, temp: 98.6, weight: 75 },
  { id: 2, date: '2026-06-01T20:00', bp: '135/88', sugar: 140, hr: 75, o2: 97, temp: 98.4, weight: 75.2 },
  { id: 3, date: '2026-06-02T08:00', bp: '142/92', sugar: 160, hr: 80, o2: 96, temp: 98.7, weight: 74.8 },
];

const DUMMY_MEDICATIONS = [
  { id: 1, name: 'Metformin', dosage: '500mg', frequency: 'Twice daily', time: '08:00, 20:00', status: 'Taken' },
  { id: 2, name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', time: '09:00', status: 'Pending' },
];

const DUMMY_NOTES = [
  { id: 1, date: '2026-05-30', content: 'Patient reports mild headache in the evening. Monitored BP, slightly elevated but stable.', author: 'Dr. Smith' },
];

export const HealthProvider = ({ children }) => {
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('health_profile');
    return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
  });

  const [vitals, setVitals] = useState(() => {
    const saved = localStorage.getItem('health_vitals');
    return saved ? JSON.parse(saved) : DUMMY_VITALS;
  });

  const [medications, setMedications] = useState(() => {
    const saved = localStorage.getItem('health_medications');
    return saved ? JSON.parse(saved) : DUMMY_MEDICATIONS;
  });

  const [notes, setNotes] = useState(() => {
    const saved = localStorage.getItem('health_notes');
    return saved ? JSON.parse(saved) : DUMMY_NOTES;
  });

  const [notifications, setNotifications] = useState([]);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    localStorage.setItem('health_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('health_vitals', JSON.stringify(vitals));
  }, [vitals]);

  useEffect(() => {
    localStorage.setItem('health_medications', JSON.stringify(medications));
  }, [medications]);

  useEffect(() => {
    localStorage.setItem('health_notes', JSON.stringify(notes));
  }, [notes]);

  // Alert Generation logic
  useEffect(() => {
    const latest = vitals[vitals.length - 1];
    if (!latest) return;

    const [systolic, diastolic] = latest.bp.split('/').map(Number);
    const newAlerts = [];

    if (systolic > 140 || diastolic > 90) newAlerts.push({ type: 'High BP', val: latest.bp, severity: 'critical' });
    if (latest.sugar > 180) newAlerts.push({ type: 'High Sugar', val: latest.sugar, severity: 'critical' });
    if (latest.hr > 120) newAlerts.push({ type: 'High Heart Rate', val: latest.hr, severity: 'warning' });
    if (latest.o2 < 92) newAlerts.push({ type: 'Low Oxygen', val: latest.o2, severity: 'critical' });

    if (newAlerts.length > 0) {
      setNotifications(prev => [
        ...newAlerts.map(a => ({
          id: Date.now() + Math.random(),
          title: `Health Alert: ${a.type}`,
          message: `${a.type} detected: ${a.val}`,
          severity: a.severity,
          time: new Date().toISOString(),
          read: false
        })),
        ...prev
      ].slice(0, 50));
    }
  }, [vitals]);

  const value = {
    profile, setProfile,
    vitals, setVitals,
    medications, setMedications,
    notes, setNotes,
    notifications, setNotifications,
    isDarkMode, setIsDarkMode
  };

  return <HealthContext.Provider value={value}>{children}</HealthContext.Provider>;
};

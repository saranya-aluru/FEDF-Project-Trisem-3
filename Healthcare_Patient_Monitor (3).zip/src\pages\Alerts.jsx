import { useHealth } from '../context/HealthContext';
import { AlertTriangle, ShieldAlert, History, Filter } from 'lucide-react';

const Alerts = () => {
  const { notifications } = useHealth();
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Health Threshold Alerts</h1>
        <div className="flex gap-2">
          <button className="btn-secondary text-sm"><Filter size={16} /> Filter</button>
          <button className="btn-secondary text-sm"><History size={16} /> History</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border border-red-100 bg-red-50 text-red-800">
          <p className="text-xs font-bold uppercase mb-1">Critical BP</p>
          <p className="text-lg font-bold">&gt; 140/90</p>
        </div>
        <div className="p-4 rounded-xl border border-red-100 bg-red-50 text-red-800">
          <p className="text-xs font-bold uppercase mb-1">Critical Sugar</p>
          <p className="text-lg font-bold">&gt; 180 mg/dL</p>
        </div>
        <div className="p-4 rounded-xl border border-amber-100 bg-amber-50 text-amber-800">
          <p className="text-xs font-bold uppercase mb-1">Warning HR</p>
          <p className="text-lg font-bold">&gt; 120 bpm</p>
        </div>
        <div className="p-4 rounded-xl border border-red-100 bg-red-50 text-red-800">
          <p className="text-xs font-bold uppercase mb-1">Low Oxygen</p>
          <p className="text-lg font-bold">&lt; 92%</p>
        </div>
      </div>

      <div className="card">
        <h2 className="text-lg font-bold mb-4">Active Notifications</h2>
        <div className="space-y-4">
          {notifications.length === 0 ? (
            <div className="text-center py-12">
              <div className="bg-hospital-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldAlert className="text-hospital-600" size={32} />
              </div>
              <p className="text-slate-500 font-medium">All systems green. No active alerts.</p>
            </div>
          ) : (
            notifications.map(alert => (
              <div key={alert.id} className={`flex items-start gap-4 p-4 rounded-xl border ${
                alert.severity === 'critical' 
                  ? 'bg-red-50/50 border-red-100' 
                  : 'bg-amber-50/50 border-amber-100'
              }`}>
                <div className={`p-2 rounded-lg ${
                  alert.severity === 'critical' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                }`}>
                  <AlertTriangle size={20} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-slate-900">{alert.title}</h3>
                    <span className="text-xs text-slate-500">{new Date(alert.time).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">{alert.message}</p>
                  <div className="flex gap-2">
                    <button className="text-xs font-bold text-hospital-600 hover:underline">Mark as Read</button>
                    <button className="text-xs font-bold text-slate-400 hover:text-red-600 transition-colors">Dismiss</button>
                  </div>
                </div>
                <div className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  alert.severity === 'critical' ? 'bg-red-600 text-white' : 'bg-amber-500 text-white'
                }`}>
                  {alert.severity}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Alerts;

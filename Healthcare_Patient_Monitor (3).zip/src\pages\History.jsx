import { useState } from 'react';
import { useHealth } from '../context/HealthContext';
import { Filter, ChevronLeft, ChevronRight, Activity, Droplets, Heart, Thermometer } from 'lucide-react';

const History = () => {
  const { vitals } = useHealth();
  const [filter, setFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const filteredVitals = vitals.slice().reverse();
  const totalPages = Math.ceil(filteredVitals.length / itemsPerPage);
  const paginatedVitals = filteredVitals.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const getVitalLabel = (type) => {
    switch(type) {
      case 'bp': return { icon: Activity, color: 'text-rose-500' };
      case 'sugar': return { icon: Droplets, color: 'text-amber-500' };
      case 'hr': return { icon: Heart, color: 'text-red-500' };
      default: return { icon: Thermometer, color: 'text-blue-500' };
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Vitals History</h1>
          <p className="text-slate-500">Comprehensive log of all health data.</p>
        </div>
        <div className="flex gap-2">
          <input type="date" className="input-field text-sm" />
          <button className="btn-secondary text-sm"><Filter size={16} /> Filter</button>
        </div>
      </div>

      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-6 py-4">Date & Time</th>
                <th className="px-6 py-4">Blood Pressure</th>
                <th className="px-6 py-4">Blood Sugar</th>
                <th className="px-6 py-4">Heart Rate</th>
                <th className="px-6 py-4">O2 %</th>
                <th className="px-6 py-4">Temp</th>
                <th className="px-6 py-4">Weight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {paginatedVitals.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-semibold text-slate-900">{new Date(item.date).toLocaleDateString()}</div>
                    <div className="text-xs text-slate-500">{new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Activity size={14} className="text-rose-500" />
                      <span className="text-sm font-medium">{item.bp} <span className="text-[10px] text-slate-400">mmHg</span></span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Droplets size={14} className="text-amber-500" />
                      <span className="text-sm font-medium">{item.sugar} <span className="text-[10px] text-slate-400">mg/dL</span></span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Heart size={14} className="text-red-500" />
                      <span className="text-sm font-medium">{item.hr} <span className="text-[10px] text-slate-400">bpm</span></span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium">{item.o2}%</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium">{item.temp}°F</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium">{item.weight} kg</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="px-6 py-4 bg-slate-50 flex items-center justify-between border-t border-slate-100">
            <span className="text-sm text-slate-500">Showing {paginatedVitals.length} of {filteredVitals.length} logs</span>
            <div className="flex gap-2">
              <button 
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1 rounded bg-white border border-slate-200 disabled:opacity-50"
              >
                <ChevronLeft size={18} />
              </button>
              <div className="flex gap-1">
                {[...Array(totalPages)].map((_, i) => (
                  <button 
                    key={i}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`w-8 h-8 rounded text-sm font-medium ${currentPage === i + 1 ? 'bg-hospital-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1 rounded bg-white border border-slate-200 disabled:opacity-50"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;

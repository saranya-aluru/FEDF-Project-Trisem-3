import { useHealth } from '../context/HealthContext';
import { Moon, Sun, Bell, Shield, Smartphone, Globe } from 'lucide-react';

const Settings = () => {
  const { isDarkMode, setIsDarkMode } = useHealth();

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="card divide-y divide-slate-100 dark:divide-slate-800">
        <div className="py-6 first:pt-0">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-100 text-indigo-600">
                {isDarkMode ? <Moon size={20} /> : <Sun size={20} />}
              </div>
              <div>
                <h3 className="font-bold">Appearance</h3>
                <p className="text-sm text-slate-500">Switch between light and dark mode</p>
              </div>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`w-12 h-6 rounded-full transition-colors relative ${isDarkMode ? 'bg-hospital-600' : 'bg-slate-300'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${isDarkMode ? 'left-7' : 'left-1'}`}></div>
            </button>
          </div>
        </div>

        <div className="py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-100 text-orange-600">
                <Bell size={20} />
              </div>
              <div>
                <h3 className="font-bold">Notifications</h3>
                <p className="text-sm text-slate-500">Health alerts and medication reminders</p>
              </div>
            </div>
            <button className="text-sm font-bold text-hospital-600">Manage</button>
          </div>
        </div>

        <div className="py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-100 text-green-600">
                <Shield size={20} />
              </div>
              <div>
                <h3 className="font-bold">Privacy & Security</h3>
                <p className="text-sm text-slate-500">Control your local data storage</p>
              </div>
            </div>
            <button className="text-sm font-bold text-red-600">Clear Storage</button>
          </div>
        </div>

        <div className="py-6 last:pb-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100 text-blue-600">
                <Globe size={20} />
              </div>
              <div>
                <h3 className="font-bold">Language</h3>
                <p className="text-sm text-slate-500">System display language</p>
              </div>
            </div>
            <select className="bg-transparent border-none font-bold text-sm outline-none cursor-pointer">
              <option>English</option>
              <option>Spanish</option>
              <option>French</option>
            </select>
          </div>
        </div>
      </div>

      <div className="card bg-hospital-100 border-hospital-200">
        <div className="flex gap-4">
          <Smartphone className="text-hospital-700" size={24} />
          <div>
            <h3 className="font-bold text-hospital-900">Mobile Sync</h3>
            <p className="text-sm text-hospital-800 mb-3">Get the HealthPlus app to monitor your health on the go.</p>
            <button className="bg-hospital-700 text-white px-4 py-1.5 rounded-lg text-xs font-bold shadow-md">Download App</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;

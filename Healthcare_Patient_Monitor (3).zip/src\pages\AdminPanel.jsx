import { useHealth } from '../context/HealthContext';
import { Users, AlertTriangle, Pill, Activity, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const AdminPanel = () => {
  const { vitals, medications, notifications } = useHealth();
  
  const stats = [
    { label: 'Total Patients', value: '1', icon: Users, color: 'blue' },
    { label: 'Critical Alerts', value: notifications.filter(n => n.severity === 'critical').length, icon: AlertTriangle, color: 'red' },
    { label: 'Medications Active', value: medications.length, icon: Pill, color: 'amber' },
    { label: 'Logs Today', value: vitals.filter(v => v.date.includes(new Date().toISOString().split('T')[0])).length, icon: Activity, color: 'green' },
  ];

  const activityData = [
    { day: 'Mon', count: 4 },
    { day: 'Tue', count: 6 },
    { day: 'Wed', count: 5 },
    { day: 'Thu', count: 8 },
    { day: 'Fri', count: 7 },
    { day: 'Sat', count: 3 },
    { day: 'Sun', count: 4 },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="card">
            <div className={`p-2 w-10 h-10 rounded-lg bg-${stat.color}-100 text-${stat.color}-600 mb-3 flex items-center justify-center`}>
              <stat.icon size={20} />
            </div>
            <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
            <h3 className="text-2xl font-bold">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <h2 className="text-lg font-bold mb-6">Patient Activity Overview</h2>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="count" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg font-bold mb-4">Recent Activities</h2>
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="flex gap-3 pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                <div className="mt-1">
                  <div className="w-2 h-2 rounded-full bg-hospital-500"></div>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-800">Vitals logged for John Doe</p>
                  <p className="text-xs text-slate-500">2 hours ago</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2 text-sm font-bold text-hospital-600 bg-hospital-50 rounded-lg hover:bg-hospital-100 transition-colors">
            View All Logs
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;

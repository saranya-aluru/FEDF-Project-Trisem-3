import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  User, 
  Activity, 
  LineChart, 
  AlertTriangle, 
  Pill, 
  ClipboardList, 
  History, 
  Bell, 
  FileDown, 
  ShieldCheck, 
  Settings, 
  Info,
  Heart
} from 'lucide-react';
import { useHealth } from '../context/HealthContext';

const Sidebar = () => {
  const location = useLocation();
  const { isDarkMode } = useHealth();

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Profile', icon: User, path: '/profile' },
    { name: 'Vitals Log', icon: Activity, path: '/vitals' },
    { name: 'Trends', icon: LineChart, path: '/trends' },
    { name: 'Alerts', icon: AlertTriangle, path: '/alerts' },
    { name: 'Medication', icon: Pill, path: '/medication' },
    { name: 'Doctor Notes', icon: ClipboardList, path: '/notes' },
    { name: 'History', icon: History, path: '/history' },
    { name: 'Notifications', icon: Bell, path: '/notifications' },
    { name: 'Export PDF', icon: FileDown, path: '/export' },
    { name: 'Admin Panel', icon: ShieldCheck, path: '/admin' },
    { name: 'Settings', icon: Settings, path: '/settings' },
    { name: 'About', icon: Info, path: '/about' },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col h-screen sticky top-0 hidden lg:flex">
      <div className="p-6 flex items-center gap-3">
        <div className="bg-hospital-600 p-2 rounded-xl">
          <Heart className="text-white w-6 h-6" fill="currentColor" />
        </div>
        <span className="font-bold text-xl text-hospital-700 dark:text-hospital-400">HealthPlus</span>
      </div>
      
      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive 
                  ? 'bg-hospital-50 dark:bg-hospital-900/30 text-hospital-600 dark:text-hospital-400 font-semibold' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <item.icon size={20} />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-200 dark:border-slate-800">
        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4">
          <p className="text-xs text-slate-500 mb-1">System Status</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-sm font-medium">Monitoring Active</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;

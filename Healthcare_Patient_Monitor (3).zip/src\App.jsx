import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HealthProvider } from './context/HealthContext';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';

// Pages
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import VitalsLog from './pages/VitalsLog';
import TrendCharts from './pages/TrendCharts';
import Alerts from './pages/Alerts';
import MedicationTracker from './pages/MedicationTracker';
import DoctorNotes from './pages/DoctorNotes';
import History from './pages/History';
import Notifications from './pages/Notifications';
import ExportPDF from './pages/ExportPDF';
import AdminPanel from './pages/AdminPanel';
import Settings from './pages/Settings';
import About from './pages/About';

function App() {
  return (
    <HealthProvider>
      <Router>
        <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
          <Sidebar />
          <div className="flex-1 flex flex-col min-w-0">
            <Navbar />
            <main className="flex-1 p-4 md:p-6 overflow-y-auto">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/vitals" element={<VitalsLog />} />
                <Route path="/trends" element={<TrendCharts />} />
                <Route path="/alerts" element={<Alerts />} />
                <Route path="/medication" element={<MedicationTracker />} />
                <Route path="/notes" element={<DoctorNotes />} />
                <Route path="/history" element={<History />} />
                <Route path="/notifications" element={<Notifications />} />
                <Route path="/export" element={<ExportPDF />} />
                <Route path="/admin" element={<AdminPanel />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/about" element={<About />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </div>
      </Router>
    </HealthProvider>
  );
}

export default App;

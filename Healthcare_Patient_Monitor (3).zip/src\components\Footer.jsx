const Footer = () => {
  return (
    <footer className="p-6 text-center border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <p className="text-sm text-slate-500 dark:text-slate-400">
        &copy; 2026 <span className="font-semibold text-hospital-600">HealthPlus</span> Patient Monitoring System. 
        All rights reserved. Professional Healthcare Solution.
      </p>
    </footer>
  );
};

export default Footer;
